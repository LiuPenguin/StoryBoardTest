//
//  tabBarVC.h
//  PHStoryBordText
//
//  Created by 钱趣多 on 2017/9/19.
//  Copyright © 2017年 LPH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface tabBarVC : UITabBarController

@end
