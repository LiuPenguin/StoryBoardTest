//
//  TableViewCell.m
//  PHStoryBoardTest
//
//  Created by 钱趣多 on 2017/9/22.
//  Copyright © 2017年 LPH. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
